public class ReverseList {
    public void reverse(SinglyLinkedList list) {
        Node previous = null; // O(1)
        Node elementoReverse = list.head; // O(1)
        Node next = null; // O(1)

        while (elementoReverse != null) { // O(n)
            next = elementoReverse.next; // O(1)
            elementoReverse.next = previous; // O(1)
            previous = elementoReverse; // O(1)
            elementoReverse = next; // O(1)
        }
        list.head = previous; // O(1)
    }
}

// O(n) + O(1) = O(n)
