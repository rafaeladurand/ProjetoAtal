public class RemoveByValue {
    public void removeByValue(SinglyLinkedList list, int value) {
        Node elementoRemover = list.head; // O(1)
        Node previous = null; // O(1)

        if (elementoRemover == null) { // O(1)
            System.out.println("A lista está vazia. Não é possível remover o elemento."); // O(1)
            return; // O(1)
        }

        while (elementoRemover != null) { // O(n)
            if (elementoRemover.value == value) { // O(1)
                if (previous == null) { // O(1)
                    list.head = elementoRemover.next; // O(1)
                } else { // O(1)
                    previous.next = elementoRemover.next; // O(1)
                }
                System.out.println("Elemento " + value + " removido com sucesso."); // O(1)
                return; // O(1)
            }
            previous = elementoRemover; // O(1)
            elementoRemover = elementoRemover.next; // O(1)
        }

        System.out.println("Elemento " + value + " não encontrado na lista."); // O(1)
    }
}
// O(n) + O(1) + O(1) = O(n)