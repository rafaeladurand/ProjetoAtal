public class AddAtPosition {
    public void addAtPosition(SinglyLinkedList list, int value, int position) {
        Node newNode = new Node(value); // O(1)
        if (position == 0) { // O(1)
            newNode.next = list.head; // O(1)
            list.head = newNode; // O(1)
            return; // O(1)
        }

        Node elemento = list.head; // O(1)
        int index = 0; // O(1)

        while (elemento != null && index < position - 1) { // O(n)
            elemento = elemento.next; // O(1)
            index++; // O(1)
        }

        if (elemento == null) { // O(1)
            System.out.println("Posição inválida. Não foi possível adicionar o elemento."); // O(1)
            return; // O(1)
        }

        newNode.next = elemento.next;// O(1)
        elemento.next = newNode; // O(1)
    }
}

// O(n) + O(1) + O(1) = O(n)
