import java.util.HashSet;

public class RemoveDuplicates {
    public void removeDuplicates(SinglyLinkedList list) {
        HashSet<Integer> seenValues = new HashSet<>(); // O(1)
        Node elementoDuplicado = list.head; // O(1)
        Node previous = null; // O(1)

        while (elementoDuplicado != null) { // O(n)
            if (seenValues.contains(elementoDuplicado.value)) { // O(1)
                previous.next = elementoDuplicado.next; // O(1)
            } else { // O(1)
                seenValues.add(elementoDuplicado.value); // O(1)
                previous = elementoDuplicado; // O(1)
            }
            elementoDuplicado = elementoDuplicado.next; // O(1)
        }
    }
}

// O(n) + O(1) + O(1) = O(n)
