public class GetMiddle {
    public Node getMiddle(SinglyLinkedList list) {
        if (list.head == null) { // O(1)
            return null; // O(1)
        }

        Node slow = list.head; // O(1)
        Node fast = list.head; // O(1)

        while (fast != null && fast.next != null) { // O(n)
            slow = slow.next; // O(1)
            fast = fast.next.next; // O(1)
        }

        return slow; // O(1)
    }
}

// O(n) + O(1) = O(n)
