public class SinglyLinkedList {
    public Node head;

    public SinglyLinkedList() {
        this.head = null; // O(1)
    }

    // Método auxiliar para exibir a lista
    public void printList() {
        Node elemento = head; // O(n)
        while (elemento != null) { // O(1)
            System.out.print(elemento.value + " "); // O(1)
            elemento = elemento.next; // O(1)
        }
        System.out.println(); // O(1)
    }
}
// O(n) + O(1) = O(n)