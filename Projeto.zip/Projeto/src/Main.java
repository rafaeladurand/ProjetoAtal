public class Main {
    public static void main(String[] args) {
        SinglyLinkedList list = new SinglyLinkedList();

        // Testando AddAtPosition
        AddAtPosition add = new AddAtPosition();
        add.addAtPosition(list, 10, 0);
        add.addAtPosition(list, 20, 1);
        add.addAtPosition(list, 15, 2);
        add.addAtPosition(list, 30, 3);
        add.addAtPosition(list, 40, 4);
        add.addAtPosition(list, 30, 5);

        System.out.print("Elementos da lista após adições: ");
        list.printList();

        // Testando RemoveByValue
        RemoveByValue remove = new RemoveByValue();
        remove.removeByValue(list, 20);
        System.out.print("Elementos da lista após remover 20: ");
        list.printList();

        // Testando ReverseList
        ReverseList reverse = new ReverseList();
        reverse.reverse(list);
        System.out.print("Elementos da lista após inversão: ");
        list.printList();

        // Testando GetMiddle
        GetMiddle middle = new GetMiddle();
        Node middleNode = middle.getMiddle(list);
        if (middleNode != null) {
            System.out.println("O nó do meio é: " + middleNode.value);
        } else {
            System.out.println("A lista está vazia.");
        }

        // Testando RemoveDuplicates
        RemoveDuplicates removeDuplicates = new RemoveDuplicates();
        removeDuplicates.removeDuplicates(list);
        System.out.print("Elementos da lista após remover duplicatas: ");
        list.printList();
    }
}
